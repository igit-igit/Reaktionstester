#ifndef Reaktometer_h
#define Reaktometer_h
#include "Arduino.h"
class RT {
  public:
    RT();
    void animation();
    void menuauswahl(); 
  private:
    void testAnimation();
    void wait_until_release();
    void test_loop1(); 
    void test_loop2(); 
    void test_loop3(); 
    void reset();
    void oneLed();
    void twoLed();
    void threeLed();
    void fourLed();
    void fiveLed();
    void sixLed();
    void sevenLed();
    int led1;
    int led2;
    int led3;
    int led4;
    int led5;
    int led6;
    int led7;
    int buttonPin;
    long start_time;
};
#endif
