#include "Arduino.h"
#include "Reaktometer.h"

//Definieren
unsigned long react_time;
unsigned long random_time;
unsigned int num_of_leds;
unsigned int pressed;
unsigned int pressed_menu;

// Konstruktor
// mit konstruktor erzeugt und initialisiert man ein objekt 
RT::RT() {
  //Pins definieren
  led1 = 3;
  led2 = 4;
  led3 = 5;
  led4 = 6;
  led5 = 7;
  led6 = 8;
  led7 = 9;
  buttonPin = 2;
  //LEDs und Button initialisieren
  pinMode(led1, OUTPUT);
  pinMode(led2, OUTPUT);
  pinMode(led3, OUTPUT);
  pinMode(led4, OUTPUT);
  pinMode(led5, OUTPUT);
  pinMode(led6, OUTPUT);
  pinMode(led7, OUTPUT);
  pinMode(buttonPin, INPUT);
  //pressed und pressed_menu Initialisieren bevor die Haupt-Loop startet
  pressed = 0;
  pressed_menu = 0;
}

//Zustände
void RT::oneLed () {
  digitalWrite(led1, HIGH);
  digitalWrite(led2, LOW);
  digitalWrite(led3, LOW);
  digitalWrite(led4, LOW);
  digitalWrite(led5, LOW);
  digitalWrite(led6, LOW);
  digitalWrite(led7, LOW);
}

void RT::twoLed () {
  digitalWrite(led1, HIGH);
  digitalWrite(led2, HIGH);
  digitalWrite(led3, LOW);
  digitalWrite(led4, LOW);
  digitalWrite(led5, LOW);
  digitalWrite(led6, LOW);
  digitalWrite(led7, LOW);
}

void RT::threeLed () {
  digitalWrite(led1, HIGH);
  digitalWrite(led2, HIGH);
  digitalWrite(led3, HIGH);
  digitalWrite(led4, LOW);
  digitalWrite(led5, LOW);
  digitalWrite(led6, LOW);
  digitalWrite(led7, LOW);
}
void RT::fourLed () {
  digitalWrite(led1, HIGH);
  digitalWrite(led2, HIGH);
  digitalWrite(led3, HIGH);
  digitalWrite(led4, HIGH);
  digitalWrite(led5, LOW);
  digitalWrite(led6, LOW);
  digitalWrite(led7, LOW);
}
void RT::fiveLed () {
  digitalWrite(led1, HIGH);
  digitalWrite(led2, HIGH);
  digitalWrite(led3, HIGH);
  digitalWrite(led4, HIGH);
  digitalWrite(led5, HIGH);
  digitalWrite(led6, LOW);
  digitalWrite(led7, LOW);
}
void RT::sixLed () {
  digitalWrite(led1, HIGH);
  digitalWrite(led2, HIGH);
  digitalWrite(led3, HIGH);
  digitalWrite(led4, HIGH);
  digitalWrite(led5, HIGH);
  digitalWrite(led6, HIGH);
  digitalWrite(led7, LOW);
}
void RT::sevenLed () {
  digitalWrite(led1, HIGH);
  digitalWrite(led2, HIGH);
  digitalWrite(led3, HIGH);
  digitalWrite(led4, HIGH);
  digitalWrite(led5, HIGH);
  digitalWrite(led6, HIGH);
  digitalWrite(led7, HIGH);
}

//Einschaltanimation
void RT::animation() {
  digitalWrite(led7, HIGH);
  delay(300);
  digitalWrite(led5, HIGH);
  delay(300);
  digitalWrite(led3, HIGH);
  delay(300);
  digitalWrite(led1, HIGH);
  delay(300);
  // zweiter durchgang
  digitalWrite(led2, HIGH);
  digitalWrite(led4, HIGH);
  digitalWrite(led6, HIGH);
  digitalWrite(led1, LOW);
  digitalWrite(led3, LOW);
  digitalWrite(led5, LOW);
  digitalWrite(led7, LOW);
  delay(300);
  digitalWrite(led2, LOW);
  digitalWrite(led4, LOW);
  digitalWrite(led6, LOW);
  digitalWrite(led1, HIGH);
  digitalWrite(led3, HIGH);
  digitalWrite(led5, HIGH);
  digitalWrite(led7, HIGH);
  delay(300);
  digitalWrite(led2, HIGH);
  digitalWrite(led4, HIGH);
  digitalWrite(led6, HIGH);
  digitalWrite(led1, LOW);
  digitalWrite(led3, LOW);
  digitalWrite(led5, LOW);
  digitalWrite(led7, LOW);
  delay(300);
  digitalWrite(led2, LOW);
  digitalWrite(led4, LOW);
  digitalWrite(led6, LOW);
  digitalWrite(led1, HIGH);
  digitalWrite(led3, HIGH);
  digitalWrite(led5, HIGH);
  digitalWrite(led7, HIGH);
  delay(300);
  digitalWrite(led2, HIGH);
  digitalWrite(led4, HIGH);
  digitalWrite(led6, HIGH);
  digitalWrite(led1, LOW);
  digitalWrite(led3, LOW);
  digitalWrite(led5, LOW);
  digitalWrite(led7, LOW);
  delay(300);
  digitalWrite(led2, LOW);
  digitalWrite(led4, LOW);
  digitalWrite(led6, LOW);
  digitalWrite(led1, HIGH);
  digitalWrite(led3, HIGH);
  digitalWrite(led5, HIGH);
  digitalWrite(led7, HIGH);
  delay(300);
  digitalWrite(led2, HIGH);
  digitalWrite(led4, HIGH);
  digitalWrite(led6, HIGH);
  digitalWrite(led1, LOW);
  digitalWrite(led3, LOW);
  digitalWrite(led5, LOW);
  digitalWrite(led7, LOW);
  delay(300);
  digitalWrite(led2, LOW);
  digitalWrite(led4, LOW);
  digitalWrite(led6, LOW);
  digitalWrite(led1, HIGH);
  digitalWrite(led3, HIGH);
  digitalWrite(led5, HIGH);
  digitalWrite(led7, HIGH);
  delay(300);
  digitalWrite(led2, HIGH);
  digitalWrite(led4, HIGH);
  digitalWrite(led6, HIGH);
  digitalWrite(led1, LOW);
  digitalWrite(led3, LOW);
  digitalWrite(led5, LOW);
  digitalWrite(led7, LOW);
  delay(300);
  digitalWrite(led2, LOW);
  digitalWrite(led4, LOW);
  digitalWrite(led6, LOW);
  digitalWrite(led1, HIGH);
  digitalWrite(led3, HIGH);
  digitalWrite(led5, HIGH);
  digitalWrite(led7, HIGH);
  delay(300);
  digitalWrite(led2, HIGH);
  digitalWrite(led4, HIGH);
  digitalWrite(led6, HIGH);
  digitalWrite(led1, LOW);
  digitalWrite(led3, LOW);
  digitalWrite(led5, LOW);
  digitalWrite(led7, LOW);
  delay(500);
  reset();
}

// Setzt alle Led's sowie die "press-Anzahlen" zurück (bevor eine neue Iteration beginnt)
void RT::reset () {
  digitalWrite(led1, LOW);
  digitalWrite(led2, LOW);
  digitalWrite(led3, LOW);
  digitalWrite(led4, LOW);
  digitalWrite(led5, LOW);
  digitalWrite(led6, LOW);
  digitalWrite(led7, LOW);
  pressed = 0;
  pressed_menu = 0;
}

// Animation bevor die Reaktionszeit gemessen wird
void RT::testAnimation () {
  digitalWrite(led1, HIGH);
  digitalWrite(led2, HIGH);
  digitalWrite(led3, HIGH);
  digitalWrite(led4, HIGH);
  digitalWrite(led5, HIGH);
  digitalWrite(led6, HIGH);
  digitalWrite(led7, HIGH);
  delay(100);
  digitalWrite(led1, LOW);
  digitalWrite(led2, LOW);
  digitalWrite(led3, LOW);
  digitalWrite(led4, LOW);
  digitalWrite(led5, LOW);
  digitalWrite(led6, LOW);
  digitalWrite(led7, LOW);
  delay(100);
  digitalWrite(led1, HIGH);
  digitalWrite(led2, HIGH);
  digitalWrite(led3, HIGH);
  digitalWrite(led4, HIGH);
  digitalWrite(led5, HIGH);
  digitalWrite(led6, HIGH);
  digitalWrite(led7, HIGH);
}

// Funktion, die langes halten ermöglicht
void RT::wait_until_release() {
  //while (true) {
  //  Serial.println(digitalRead(buttonPin));
  while (digitalRead(buttonPin) != LOW) {
     Serial.println(digitalRead(buttonPin));
    // digitalWrite(led7, HIGH);
    // delay(100);
  }
  // digitalWrite(led7, LOW);
}

// Funktion die die Zeitmessung sowie die Darstellung des Ergebnisses realisiert
void RT::test_loop1() {
  //Zeitmessung starten
  start_time = millis();
  //Generieren der Zufallszeit
  random_time = random(10001);
  //Ausgabe der Zufallszeit
  Serial.println(random_time);
  // TestAnimation
  while ((millis() - start_time < random_time)) {
    testAnimation();
  }
  reset();
  // Zeitmessung nach dem alle LEDs ausgschaltet sind
  start_time = millis();
  // Solange nicht gedrückt wurde bleibt er in while, wenn HIGH geht er aus while raus und
  // errechnet die Reaktionszeit
  while (digitalRead(buttonPin) != HIGH) {
  }
  react_time = millis() - start_time;
  Serial.println(react_time);
  num_of_leds = react_time;

  switch (num_of_leds) {
    // Ab 140 beginnen damit der benutzer nicht dauerhaft drückt und 1 led angezeigt wird
    case 140 ... 190:
      oneLed();
      break;

    case 191 ... 250:
      twoLed();
      break;

    case 251 ... 300:
      threeLed();
      break;

    case 301 ... 400:
      fourLed();
      break;

    case 401 ... 500:
      fiveLed();
      break;

    case 501 ... 600:
      sixLed();
      break;

    // Auf 7 LEDs begrenzt -> alles über 600 ms mit 7 LEDs anzeigen
    default:
      sevenLed();
      break;
  }
}

void RT::test_loop2() {
  start_time = millis();
  random_time = random(10001);
  Serial.println(random_time);
  while ((millis() - start_time < random_time)) {
    testAnimation();
  }
  reset();
  start_time = millis();
  while (digitalRead(buttonPin) != HIGH) {
  }
  react_time = millis() - start_time;
  Serial.println(react_time);
  num_of_leds = react_time;

  switch (num_of_leds) {
    case 140 ... 175:
      oneLed();
      break;

    case 176 ... 200:
      twoLed();
      break;

    case 201 ... 240:
      threeLed();
      break;

    case 241 ... 300:
      fourLed();
      break;

    case 301 ... 350:
      fiveLed();
      break;

    case 351 ... 450:
      sixLed();
      break;
    default:
      sevenLed();
      break;
  }
}

void RT::test_loop3() {
  start_time = millis();
  random_time = random(10001);
  Serial.println(random_time);
  while ((millis() - start_time < random_time)) {
    testAnimation();
  }
  reset();
  start_time = millis();
  while (digitalRead(buttonPin) != HIGH) {
  }
  react_time = millis() - start_time;
  Serial.println(react_time);
  num_of_leds = react_time;

  switch (num_of_leds) {
    case 140 ... 160:
      oneLed();
      break;

    case 161 ... 170:
      twoLed();
      break;

    case 171 ... 190:
      threeLed();
      break;

    case 191 ... 250:
      fourLed();
      break;

    case 251 ... 300:
      fiveLed();
      break;

    case 301 ... 380:
      sixLed();
      break;
    default:
      sevenLed();
      break;
  }
}

void RT::menuauswahl() {
  Serial.begin(9600);
  randomSeed(analogRead(0));
  start_time = millis();
  do {
    if (digitalRead(buttonPin) == HIGH) {
      wait_until_release();
      pressed = pressed + 1;
    }
  }
  while (((pressed == 0) || (pressed == 1) || (pressed == 2)) && (millis() - start_time <= 5000));
  pressed_menu = pressed;

  switch (pressed_menu) {
    case 1 :
      oneLed();
      delay(3000);
      reset();
      delay(500);
      test_loop1();
      delay(4000);
      reset();
      break;
    case 2 :
      twoLed();
      delay(3000);
      reset();
      delay(500);
      test_loop2();
      delay(4000);
      reset();
      break;
    case 3 :
      threeLed();
      delay(3000);
      reset();
      delay(500);
      test_loop3();
      delay(4000);
      reset();
      break;
    default:
      break;
  }
}
